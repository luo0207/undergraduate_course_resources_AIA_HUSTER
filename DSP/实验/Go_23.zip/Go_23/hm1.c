//#include "DSP28x_Project.h"
//#include "LED_TM1638.h"
//
// interrupt void cpu_timer0_isr(void);  //timer0
// interrupt void myXint1_isr(void);     //xint1
//// interrupt void EPWM4Int_isr(void);    //EPWM4
//// interrupt void Ecap1Int_isr(void);    //ECAP1
//// interrupt void MyAdcInt1_isr(void);   //ADCINT1
//
////��ʼ������
//       int hourH =0 ;int hourL =0;
//       int minH = 0;int minL = 0;
//       int secH = 0;int secL =0; int TenmS =0;
//       int HorseType = 0;//�����Ƶ�����
//       int keyDLTime = 0;//����ȥ����
//       int LedFlashCtr = 0 ;//��������ܵ���ʾ
//       int NewLedEn = 0;
//       int Begin =1;
//
//void HorseRunning(int16 no);
//
//#define Led0Blink() GpioDataRegs.GPACLEAR.bit.GPIO0 = 1
//#define Led1Blink() GpioDataRegs.GPACLEAR.bit.GPIO1 = 1
//#define Led2Blink() GpioDataRegs.GPACLEAR.bit.GPIO2 = 1
//#define Led3Blink() GpioDataRegs.GPACLEAR.bit.GPIO3 = 1
//#define Led0Blank() GpioDataRegs.GPASET.bit.GPIO0 = 1
//#define Led1Blank() GpioDataRegs.GPASET.bit.GPIO1 = 1
//#define Led2Blank() GpioDataRegs.GPASET.bit.GPIO2 = 1
//#define Led3Blank() GpioDataRegs.GPASET.bit.GPIO3 = 1
//
//void  Xint1_Init()
//{
//    EALLOW;
//    GpioCtrlRegs.GPAPUD.bit.GPIO12 = 0;
//    GpioCtrlRegs.GPAMUX1.bit.GPIO12 = 0;
//    GpioCtrlRegs.GPADIR.bit.GPIO12 = 0;
//    GpioIntRegs.GPIOXINT1SEL.bit.GPIOSEL = 12;
//    XIntruptRegs.XINT1CR.bit.POLARITY = 0;//�½���
//    XIntruptRegs.XINT1CR.bit.ENABLE = 1;
//    EDIS;
//}
//
//void HorseIO_Init()
//{
//    EALLOW;
//    GpioDataRegs.GPASET.bit.GPIO0 = 1;
//    GpioDataRegs.GPASET.bit.GPIO1 = 1;
//    GpioDataRegs.GPASET.bit.GPIO2 = 1;
//    GpioDataRegs.GPASET.bit.GPIO3 = 1;
//    GpioCtrlRegs.GPAMUX1.bit.GPIO0 = 0;
//    GpioCtrlRegs.GPADIR.bit.GPIO0 = 1;
//    GpioCtrlRegs.GPAMUX1.bit.GPIO1 = 0;
//    GpioCtrlRegs.GPADIR.bit.GPIO1 = 1;
//    GpioCtrlRegs.GPAMUX1.bit.GPIO2 = 0;
//    GpioCtrlRegs.GPADIR.bit.GPIO2 = 1;
//    GpioCtrlRegs.GPAMUX1.bit.GPIO3 = 0;
//    GpioCtrlRegs.GPADIR.bit.GPIO3 = 1;
//    EDIS;
//
//}
//
//void DelaymS(int tm)
//{
//  int i;
//  unsigned int j;
//    for(i = 0;i < tm ;i++){
//      j =  60000;
//      while(j != 0)j--;
//      }
//}
//void main(void)
//{
//      InitSysCtrl();    //��ʼ��ϵͳʱ�ӣ�ѡ���ڲ�����1��10MHZ��12��Ƶ��2��Ƶ����ʼ������ʱ�ӣ���������,4��Ƶ
//      DINT;                 //�����ж�
//      IER = 0x0000;         //��CPU�ж�ʹ��
//      IFR = 0x0000;     //��CPU�жϱ�־
//      InitPieCtrl();    //��pie�ж�
//      InitPieVectTable();   //���ж�������
//      EALLOW;               //�����ж�������
//      PieVectTable.TINT0 = &cpu_timer0_isr;
//      PieVectTable.XINT1 = &myXint1_isr;
//      // PieVectTable.ECAP1_INT = &Ecap1Int_isr;
//      // PieVectTable.EPWM4_INT = &EPWM4Int_isr;
//      // PieVectTable.ADCINT1 = &MyAdcInt1_isr;
//      PieCtrlRegs.PIEIER1.bit.INTx7 = 1;
//      PieCtrlRegs.PIEIER1.bit.INTx4 = 1;
//      IER |= 1;
//      EDIS;
//
//
//     //  MemCopy(&RamfuncsLoadStart, &RamfuncsLoadEnd, &RamfuncsRunStart);
//      InitFlash();
//      HorseIO_Init();
//      Xint1_Init();
//      TM1638_Init();        //��ʼ��LED
//
//
//      InitCpuTimers();      // ��ʼ����ʱ��
//      ConfigCpuTimer(&CpuTimer0, 60, 10000);//����ʱ�ӵ���Ӧʱ��Ϊ0.01s
//      EALLOW;
//      CpuTimer0Regs.TCR.bit.TRB = 1;
//      CpuTimer0Regs.TCR.bit.TSS = 0;
//      EDIS;
//
//
//
//      EINT;//�ж���ʹ��
//      ERTM;
//
//
//      while(1)
//      {
//        //if(NewLedEn == 0)
//          {
//              LED_Show(1,(TenmS % 10),0);
//              LED_Show(2,(TenmS / 10),0);
//              LED_Show(3,secL,1);
//              LED_Show(4,secH,0);
//              LED_Show(5,minL,1);
//              LED_Show(6,minH,0);
//              LED_Show(7,hourL,1);
//              LED_Show(8,hourH,0);
//              NewLedEn = 1;
//          }
//
//      }
//
//}
//
//void HorseRunning(int no)
//{
//    if(no & 0x1)Led0Blink();
//    else Led0Blank();
//    if(no & 0x2)Led1Blink();
//    else Led1Blank();
//    if(no & 0x4)Led2Blink();
//    else Led2Blank();
//    if(no & 0x8)Led3Blink();
//    else Led3Blank();
//}
//void HorseRunning1(int no)
//{
//    if(no & 0x1)    Led0Blink();
//    else    Led0Blank();
//    if(no & 0x2)
//        {Led0Blink();Led1Blink();}
//    else
//        {Led0Blank();Led1Blank();}
//    if(no & 0x4)
//        {Led2Blink();Led1Blink();}
//    else
//        {Led2Blank();Led1Blank();}
//    if(no & 0x8)
//        {Led3Blink();Led2Blink();}
//    else
//        {Led3Blank();Led2Blank();}
//
//}
//
//
//interrupt void myXint1_isr(void)
//{
//    Begin = 1;
//    if((HorseType == 0)&&(keyDLTime>20))
//        {
//            HorseType = 1; keyDLTime = 0;
//        }
//        else if((HorseType == 1)&&(keyDLTime>20))
//        {
//            HorseType = 0; keyDLTime = 0;
//        }
//   PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;//�ֶ����������жϱ�־ all=0x0001Ҳ��
//   EALLOW;
//   CpuTimer0Regs.TCR.bit.TRB = 1;
//   CpuTimer0Regs.TCR.bit.TSS = 0;
//   EDIS;
//}
//
//interrupt void cpu_timer0_isr(void) {
//    keyDLTime++;
//    LedFlashCtr++;
//    if((LedFlashCtr & 0xf)==0) NewLedEn = 0;
//    if(Begin == 1){
//        TenmS ++;
//        if(TenmS == 100){TenmS = 0; secL++;}
//        if(secL == 10){secL = 0; secH++;}
//        if(secH == 6){secH = 0; minL++;}
//        if(minL == 10){minL = 0; minH++;}
//        if(minH == 6){minH = 0; hourL++;}
//        if(hourH == 2 && hourL ==4){hourH = 0; hourL =0;}
//        else if(hourL == 10){hourL = 0; hourH++;}
//    }
//    if(HorseType == 0 && Begin == 1){HorseRunning((LedFlashCtr&0xf0)>>4);}
//    else if(HorseType == 1 && Begin == 1){HorseRunning1((LedFlashCtr&0xf0)>>4);}
//    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
//}
