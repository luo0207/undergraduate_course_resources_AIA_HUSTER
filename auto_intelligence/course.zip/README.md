# teb_local_planner_tutorials

teb_local_planner codeAPI 及 参数含义 [teb_local_planner](http://wiki.ros.org/teb_local_planner) tutorials.

**Dependencies:**
`以下两个二选一`
* *ros-noetic*：  `sudo apt install ros-noetic-desktop-full`            `20.04装这个`
* *ros-melodic*：  `sudo apt install ros-melodic-desktop-full`          `18.04装这个`
`以下两个都要装`
* *navigation stack*：  `sudo apt install ros-$ROS_DISTRO-navigation`
* *teb_local_planner*： `sudo apt install ros-$ROS_DISTRO-teb-local-planner`

**Build:** 

把course.tar.gz在主目录下,打开终端：

    unzip course.zip
    cd course/src
    catkin_init_workspace
    cd ..
    catkin_make
    gedit ~/.bashrc
    source ~/course/devel/setup.bash

**Run:**

    roslaunch course run.launch

**Modification:**

* 修改`src\config`中的`yaml`文件参数，改进teb_local_planner的效果
* 使用其他算法替换teb_local_planner，如`dwa_local_planner`，`eband_local_planner`
